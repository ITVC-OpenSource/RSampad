<?php
if (!is_active_sidebar('sidebar-left')) {
    return;
}
?>
<aside class="matchHeight col-md-4 sidebar">
    <div class="sidebar__inner">
        <?php dynamic_sidebar('sidebar-left'); ?>
    </div>
</aside>