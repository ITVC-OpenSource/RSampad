</div>
</div></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="pull-right">&copy; کلیه حقوق این وبسایت مطعلق به <b>دبیرستان استعداد های درخشان رمضانخانی دوره
                    اول</b> می باشد.
                <br>
                طراحی شده با
                &heartsuit;
                توسط محمدصادق دهقان.
            </div>
            <div class="pull-left">
                <div class="social-logo insta-logo"></div>
                <div class="social-logo telegram-logo"></div>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
<script>
    jQuery('.matchHeight').matchHeight();
</script>
</body>
</html>