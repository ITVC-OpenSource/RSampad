<!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
    <!-- [if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif] -->
</head>
<body <?php body_class(); ?>>
<div class="address-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-right">
                <address>&#128205; : یزد، بلوار ۱۷ شهریور،جنب بلوار عابدی،کوچه ی ژاندارمری</address>
            </div>
            <div class="col-md-6 text-left">&#128222;: <a href="tel:+983538123456">۰۳۵۳۱۲۳۴۵۶۷</a>|<a
                        href="tel:+983538123456">۰۳۵۳۱۲۳۴۵۶۷</a>
            </div>
        </div>
    </div>
</div>
<header id="head">
    <h1>
        <?php
        if (has_custom_logo()):
            the_custom_logo();
        else:
            ?>
            <img class="img-responsive"
                 src="<?= get_template_directory_uri(); ?>/assets/images/arm.png"
                 alt="دبیرستان استعداد های درخشان شهید رمضانخانی دوره اول" width="400" height="250">
        <?php endif;
        ?>
    </h1>
    <nav class="navbar navbar-default">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#navbar" aria-expanded="false">
                    <span class="sr-only">باز کردن منو</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <?php
            wp_nav_menu(array(
//                    'menu' => 'primary',
                    'theme_location' => 'top_menu',
                    'depth' => 2,
                    'container' => 'div',
                    'container_class' => 'collapse navbar-collapse',
                    'container_id' => 'navbar',
                    'menu_class' => 'nav navbar-nav',
                    'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                    'walker' => new wp_bootstrap_navwalker())
            );
            ?>
        </div><!-- /.container-fluid -->
    </nav>
</header>
<div class="wrapper">
    <div class="container">
        <div class="row" id="main-content">