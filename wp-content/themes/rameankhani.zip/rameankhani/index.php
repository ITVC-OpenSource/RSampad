<?php get_header(); ?>
        <div class="post-container <?= is_active_sidebar('sidebar-left') ? 'matchHeight col-md-8' : 'col-md-12'; ?>">
            <?php
            if (have_posts()):
                while (have_posts()):
                    the_post();
                    ?>
                    <div class="post">
                        <div class="post-date">
                            <div class="day"><?php echo get_the_date('j'); ?></div>
                            <div class="post-month"><?php echo get_the_date('F'); ?></div>
                        </div>
                        <div class="post-content">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                    <?php the_post_thumbnail('post-thumbnail',array('class'=> 'post-image img-responsive pull-right')); ?>
                                </a>
                            <?php endif; ?>
                            <h2 class="post-title"><a href="<?php echo esc_url(get_permalink()) ?>"
                                                      rel="bookmark"><?php the_title() ?></a></h2>
                            <div class="post-text">
                                <?php the_content('ادامه مطلب'); ?>
                            </div>
                        </div>
                    </div>
                    <?php
                endwhile;
            endif;
            ?>
            <?php the_posts_pagination(); ?>
        </div>
        <?php get_sidebar(); ?>
<?php get_footer(); ?>